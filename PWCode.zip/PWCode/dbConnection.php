<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
 

$username = "SYSTEM";
$password = "S456l@qw";
$dbname = "139.47.169.67/PWEngine";

 

//$connection = oci_connect($username, $password, $dbname);

$connection = mysqli_connect("localhost","root","","pwengine") or die(mysql_error());

 

if(!$connection){
    echo "somthing wrong";
}
 

?>