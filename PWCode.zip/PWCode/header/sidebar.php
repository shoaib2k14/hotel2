<!-- Sidebar -->
			<div class="sidebar" id="sidebar">
				<div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>
							
							<li id="dashboard">
								<a href="index.php"><i class="fa fa-dashboard"></i> <span>Dashboard</span></a>
							</li>
							<li class="list-divider"></li>
	
	
							<li id="pwusers" class="">
								<a href="all-users.php"><i class="fa fa-suitcase"></i> <span> PW Users </span> <span
										class="menu-arrow"></span></a>
							</li>
							
							
							<li id="pwconnects" class="">
								<a href="all-connects.php"><i class="fa fa-user"></i> <span> PW Connects </span> <span
										class="menu-arrow"></span></a>
							</li>
						   
							
							<li id="pwroles" class="">
								<a href="all-roles.php"><i class="fa fa-key"></i> <span> PW Roles </span> <span
										class="menu-arrow"></span></a>
							</li>
							
							
							<li id="pwgroups" class="">
								<a href="all-groups.php"><i class="fa fa-user"></i> <span> PW Groups </span> <span
										class="menu-arrow"></span></a>
							</li>
							
						</ul>
					</div>
				</div>
			</div>
<!-- /Sidebar -->