<?php

$sql = "select * from ".$table_name;

/*** For oracle ***/
	//$result = oci_parse($connection, $sql);
	//oci_execute($result);

/*** For mysql ***/
	$result = mysqli_query($connection,$sql);
	//$count = mysqli_num_rows($result);

?>