<?php

if(isset($_REQUEST['update_user'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}

if(isset($_REQUEST['update_role'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWROLES SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_groups'])){
	if(($_REQUEST['name'] == '') || ($_REQUEST['description'] == '') || ($_REQUEST['status'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$name = $_REQUEST['name'];
		$description = $_REQUEST['description'];
		$status = $_REQUEST['status'];
		
		$sql = 'UPDATE PWGROUPS SET NAME=:name, DESCRIPTION=:description, STATUS=:status WHERE ID=:id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':id', $id);
		oci_bind_by_name($parse, ':name', $name);
		oci_bind_by_name($parse, ':description', $description);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}


if(isset($_REQUEST['update_connection'])){
	if(($_REQUEST['f_name'] == '') || ($_REQUEST['l_name'] == '') || ($_REQUEST['email'] == '') || ($_REQUEST['phone'] == '') || ($_REQUEST['mobile'] == '') || ($_REQUEST['company'] == '') || ($_REQUEST['department'] == '') || ($_REQUEST['position'] == '')){
		$alert = '<div class="alert alert-warning col-sm-12" role="alert"> Please fill all the fields </div>';
	}
	else{
		$f_name = $_REQUEST['f_name'];
		$l_name = $_REQUEST['l_name'];
		$email = $_REQUEST['email'];
		$phone = $_REQUEST['phone'];
		$mobile = $_REQUEST['mobile'];
		$company = $_REQUEST['company'];
		$department = $_REQUEST['department'];
		$position = $_REQUEST['position'];
		$date = $_REQUEST['date'];
		$status = 1;
		
		$sql = 'UPDATE PWUSERS SET FIRST_NAME=:f_name, LAST_NAME=:l_name, EMAIL=:email, PHONE=:phone, MOBILE=:mobile, COMPANY=:company, DEPARTMENT=:department, POSITION=:position, STATUS=:status WHERE ID=:user_id';
		
		$parse = oci_parse($connection, $sql);
		
		
		oci_bind_by_name($parse, ':user_id', $user_id);
		oci_bind_by_name($parse, ':f_name', $f_name);
		oci_bind_by_name($parse, ':l_name', $l_name);
		oci_bind_by_name($parse, ':email', $email);
		oci_bind_by_name($parse, ':phone', $phone);
		oci_bind_by_name($parse, ':mobile', $mobile);
		oci_bind_by_name($parse, ':company', $company);
		oci_bind_by_name($parse, ':department', $department);
		oci_bind_by_name($parse, ':position', $position);
		//oci_bind_by_name($parse, ':date', $date);
		oci_bind_by_name($parse, ':status', $status);
		
		$execute = oci_execute($parse);
		
		
		if($execute){
			$alert = '<div class="alert alert-success col-sm-12" role="alert"> Inserted successfully </div>';
		}
		else{
			$alert = '<div class="alert alert-danger col-sm-12" role="alert"> Somthing went wrong </div>';
		}
		
		oci_free_statement($parse);
		oci_close($connection);
	}
}



?>